
//
// Nome :Joaquim Andrade
//
// N. Mec. :93432
//

#include <stdio.h>
#include "BinImage.c"
#include "BinImage.h"

int main(void) {
  //long unsigned int a= 1;
  
  //Image* test1= ImageCreate(6, 4);
  
  //uncoment to test display
  //ImageDisplay(test1);
  
  //uncoment to test imageload
  Image* test = ImageLoad("imagem02.txt");
  ImageDisplay(test);
  
  //uncoment to test imagecopy
  //Image* copy= ImageCopy(test);
  
  //uncoment to test save 
  //ImageSave(test, "img3.txt");

  //uncomment to test imagegetpixel
  //printf("%d",ImageGetPixel(test, 2,2)); 
  
  //uncomment to test imagesetpixel
  /*ImageSetPixel(test1, 1, 2, a);
  ImageDisplay(test1);*/
  
  //uncoment to test image set ones
  /*ImageSetToONES(test1);
  ImageDisplay(test1);*/
  
  //uncoment to test image set zeros
  /*ImageSetToZEROS(test1);
  ImageDisplay(test1);*/

  //uncomment to test image add column
  /*ImageAddColumn(test, 2);
  ImageDisplay(test);*/
  
  //uncomment to test image add row
  /*ImageAddRow(test,1);
  ImageDisplay(test);*/
  //uncoment to test horizontal split
  Image* presult;
  Image* presult2;
  //ImageHorizontalSplit(*test, 2 ,&presult, &presult2);
  ImageVerticalSplit(*test, 2 ,&presult, &presult2);
  //uncomment to rotate 90 degrees
  /*ImageRotate90DegCW(test1);
  ImageDisplay(test1);*/
  
  //uncoment to check negate
  /*ImageNEGATE(test);
  ImageDisplay(test1);*/
  
  //uncoment to test valid rect
  /*int a= ImageValidRect(test, 0, 0, 6, 5);
  printf("%d", a);*/
    
  //uncoment to test imageequalto
  //printf("%d",ImageEqualTo(test, *test));
  
  //uncoment to test imageCrop
  /*Image* new= ImageCrop(test, 1,1,2,3 );
    ImageDisplay(new);*/

  //uncoment to test imagePaste
  /*ImagePaste(test, 0,0, new);
  ImageDisplay(new);*/

  //uncoment to test imagelocatesubimage
  /*uint32 px=0;
  uint32 py=0;
  int a=ImageLocateSubImage(test, test, &px, &py);
  printf("%d",a );
  }*/

  //uncoment to test image add column
  /*ImageAddColumn(test, 0);
  ImageDisplay(test);*/
  
  //uncoment to test image add row
  /*ImageAddRow(test, 1);
  ImageDisplay(test);*/
  
  //uncoment to test horizontal or vertical join
  /*Image* presult;
  ImageHorizontalJoin(test, test1, &presult);
  ImageVerticalJoin(test, test1, &presult);*/
  
  
  //uncoment to test rotate clockwise 
  /*ImageRotate90DegCW(test);
  ImageDisplay(test);*/
  
  //uncoment to test rotate counter clock wise
  /*ImageRotate90DegCCW(test);
  ImageDisplay(test);*/
  ImageDestroy(&test);
  return 0;
}
