//
// Joaquim Madeira, AlgC, August 2020
//
// Binary image ADT based on a 1D array
//
// Adapted from an older example by J. Madeira and J. M. Rodrigues
//

#ifndef _BIN_IMAGE_
#define _BIN_IMAGE_

#include <inttypes.h>

// Type for binary pixel values (ZERO or ONE)
typedef uint8_t uint8;

// Type for image size
typedef uint32_t uint32;

// Type for number of pixels
typedef uint64_t uint64;

// Binary image
typedef struct _BinImage Image;

/// Create a new image, filled with ZEROS.
///   width, height : the dimensions of the new image.
///   Upper-left corner is (0,0).
///   Lower-right corner is (width-1,height-1).
/// Requires: width and height must be POSITIVE.
/// On success, a new image is returned.
/// On failure, returns NULL.
Image* ImageCreate(uint32 width, uint32 height);

/// Destroy the image pointed to by (*p).
///   p : address of a Image pointer variable.
/// If (*p)==NULL, no operation is performed.
/// Ensures: (*p)==NULL.
/// Should never fail.
void ImageDestroy(Image** p);

/// Create a DEEP COPY of the given image.
/// On success, the image copy is returned.
/// On failure, returns NULL.
Image* ImageCopy(const Image* img);

/// Load a TXT image file.
/// Example
///     2
///     3
///     000
///     101
/// On success, a new image is returned.
/// On failure, returns NULL.
Image* ImageLoad(const char* filename);

/// Save an image to TXT file.
/// On success, returns 1.
/// On failure, returns 0.
int ImageSave(const Image* img, const char* filename);

/// Display an image.
void ImageDisplay(const Image* img);

/// Get image width, i.e., the number of columns.
uint32 ImageGetWidth(const Image* img);

/// Get image height, i.e., the number of rows.
uint32 ImageGetHeight(const Image* img);

/// Count the number of ZERO and ONE pixels.
/// Update (*numZeros) and (*numOnes) with those counts.
void ImageStats(const Image* img, uint64* numZeros, uint64* numOnes);

/// Check if pixel position (x,y) is inside img.
/// On success, returns 1.
/// On failure, returns 0.
int ImageValidPos(const Image* img, uint32 x, uint32 y);

/// Get the pixel value at position (x,y).
/// Requires: x and y must be valid pixel coordinates.
/// On success, returns the pixel value.
/// On failure, returns 0.
uint8 ImageGetPixel(const Image* img, uint32 x, uint32 y);

/// Set the pixel at position (x,y) to new value.
/// Requires: x and y must be valid pixel coordinates.
/// Requires: value must be ZERO or ONE.
/// On success, returns 1.
/// On failure, returns 0.
int ImageSetPixel(Image* img, uint32 x, uint32 y, uint8 value);

/// Set all image pixels to ONE.
/// Should never fail.
void ImageSetToONES(Image* img);

/// Set all image pixels to ZERO.
/// Should never fail.
void ImageSetToZEROS(Image* img);

/// Add a new column of ZEROS to the image.
/// Allocate a new array and shift columns, if necessary.
/// Requires: index must be valid, i.e., 0 <= index <= width.
/// On success, returns 1.
/// On failure, returns 0.
int ImageAddColumn(Image* img, uint32 index);

/// Add a new row of ZEROS to the image.
/// Allocate a new array and shift rows, if necessary.
/// Requires: index must be valid, i.e., 0 <= index <= height.
/// On success, returns 1.
/// On failure, returns 0.
int ImageAddRow(Image* img, uint32 index);

/// Create a new image by joining img2 at the right of img1.
/// Requires: both images must have the same number of rows.
/// On success, returns 1.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageHorizontalJoin(const Image* img1, const Image* img2, Image** pResult);

/// Create a new image by joining img2 at the bottom of img1.
/// Requires: both images must have the same number of columns.
/// On success, returns 1.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageVerticalJoin(const Image* img1, const Image* img2, Image** pResult);

/// Create two new images by splitting img.
/// The splitIndex row is the first row of the second image.
/// No empty images are created.
/// Requires: splitIndex must be a valid index.
/// I.e., 0 < splitIndex < (height - 1).
/// On success, returns 1.
/// Return 0 and set (*pResult1) and (*pResult2) to NULL, otherwise.
int ImageHorizontalSplit(const Image img, uint32 splitIndex, Image** pResult1,
                         Image** pResult2);

/// Create two new images by splitting img.
/// The splitIndex column is the first column of the second image.
/// No empty images are created.
/// Requires: splitIndex must be a valid index.
/// I.e, 0 < splitIndex < (width - 1).
/// On success, returns 1.
/// Return 0 and set (*pResult1) and (*pResult2) to NULL, otherwise.
int ImageVerticalSplit(const Image img, uint32 splitIndex, Image** pResult1,
                       Image** pResult2);

/// Rotate the image 90 degrees clockwise.
/// Reallocate memory if the image is not a square image.
/// On success, returns 1.
/// On failure, returns 0.
int ImageRotate90DegCW(Image* img);

/// Rotate the image 90 degrees counter-clockwise.
/// Reallocate memory if the image is not a square image.
/// On success, returns 1.
/// On failure, returns 0.
int ImageRotate90DegCCW(Image* img);

/// Check if two images are the same.
/// I.e., they have the same size and the same pixel values.
int ImageEqualTo(const Image* img1, const Image img2);

/// Check if two images are different.
int ImageDifferentFrom(const Image* img1, const Image img2);

/// Negate each one of the image pixels.
/// Should never fail.
void ImageNEGATE(Image* img);

/// Pixel by pixel AND.
/// Create a new result image.
/// Return 1, if images are of the same size.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageAND(const Image* img1, const Image* img2, Image** pResult);

/// Pixel by pixel OR
/// Pixel by pixel AND.
/// Return 1, if images are of the same size.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageOR(const Image* img1, const Image* img2, Image** pResult);

/// Pixel by pixel XOR
/// Pixel by pixel AND.
/// Return 1, if images are of the same size.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageXOR(const Image* img1, const Image* img2, Image** pResult);

/// Check if rectangular area (x,y,w,h) is completely inside img.
int ImageValidRect(const Image* img, uint32 x, uint32 y, uint32 width,
                   uint32 height);

/// Crop a rectangular subimage from img.
/// The rectangle is specified by the top left corner coords (x, y) and
/// width w and height h.
/// Requires:
///   The rectangle must be inside the original image.
/// Ensures:
///   The original img is not modified.
///   The returned image has width w and height h.
/// On success, a new image is returned.
/// On failure, returns NULL.
Image* ImageCrop(const Image* img, uint32 x, uint32 y, uint32 width,
                 uint32 height);

/// Paste an image into a larger image.
/// Paste img2 into position (x, y) of img1.
/// This modifies img1 in-place: no allocation involved.
/// Requires: img2 must fit inside img1 at position (x, y).
/// On success, returns 1.
/// On failure, returns 0.
int ImagePaste(Image* img1, uint32 x, uint32 y, const Image* img2);

/// Locate a subimage inside another image.
/// Searches for img2 inside img1.
/// If a match is found, returns 1 and matching position is set in (*px,*py).
/// If no match is found, returns 0 and (*px, *py) are left untouched.
int ImageLocateSubImage(const Image* img1, const Image* img2, uint32* px,
                        uint32* py);

#endif  // _BIN_IMAGE_
