//
// Nome : Joaquim Pedro Gonçalves Andrade
//
// N. Mec. : 93432
//

#include "BinImage.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

struct _BinImage {
  uint32 width;   // number of columns
  uint32 height;  // number of rows
  uint8* image;   // the image pixels (stored in a 1D array)
};

/// Create a new image, filled with ZEROS.
///   width, height : the dimensions of the new image.
///   Upper-left corner is (0,0).
///   Lower-right corner is (width-1,height-1).
/// Requires: width and height must be POSITIVE.
/// On success, a new image is returned.
/// On failure, returns NULL.
Image* ImageCreate(uint32 width, uint32 height) {
  Image* g = (Image*) malloc(sizeof(g));

  if (g == NULL) return NULL;
  g->width = width;
  g->height = height;
  uint32 quant= width*height;
  g->image = (uint8*) malloc(quant * sizeof(uint8*));
  for(int i = 0; i < quant; i++) {
    g->image[i] = 0;
  }
  return g;
}
/// Destroy the image pointed to by (*p).
///   p : address of a Image pointer variable.
/// If (*p)==NULL, no operation is performed.
/// Ensures: (*p)==NULL.
/// Should never fail.
void ImageDestroy(Image** p) {
  assert(*p != NULL);

  free((*p)->image);
  free(*p);
  *p= NULL;
}


/// Create a DEEP COPY of the given image.
/// On success, the image copy is returned.
/// On failure, returns NULL.
Image* ImageCopy(const Image* img) {
  Image* copy = ImageCreate(ImageGetWidth(img), ImageGetHeight(img));
  if(copy== NULL) return NULL;
  
  int size= ImageGetHeight(img)*ImageGetWidth(img);
  for(int i=0; i<size; i++){
    copy->image[i] = img->image[i];
  }
  return copy;
}


/// Load a TXT image file.
/// Example
///     2
///     3
///     000
///     101
/// On success, a new image is returned.
/// On failure, returns NULL.
Image* ImageLoad(const char* filename) {//cria uma imagem e lẽ caracteres para dentro dela
  FILE *fich;
  fich= fopen(filename, "r");
  int hei;
  int wid;
  int d=0;
  char e;
  uint8 a=0;
  fscanf(fich, "%u\n", &hei);
  fscanf(fich, "%u", &wid);
  Image* loa= ImageCreate(wid, hei);
  for(int i=0; i<hei; i++){
    fscanf(fich, "\n");
    for(int c=0; c< wid; c++){
        fscanf(fich,"%c", &e);
        a=e-'0';                  //transforma caracter em numero
        loa->image[d]= a;
        d++;
    }
  }
  fclose(fich);  
  return loa;


 }

/// Save an image to TXT file.
/// On success, returns 1.
/// On failure, returns 0.
int ImageSave(const Image* img, const char* filename) { 
  FILE *fich;
  fich= fopen(filename, "w");
  fprintf(fich, "%d\n", ImageGetWidth(img));
  fprintf(fich, "%d\n", ImageGetHeight(img));
  uint32 d=0;
  for(uint32 i=0; i<ImageGetHeight(img); i++){
    for(uint32 c=0; c< ImageGetWidth(img); c++){//percorre toda a imagem e da print num ficheiro caracter a caracter
        fprintf(fich,"%d", img->image[d]);
        d++;
    }
    fprintf(fich, "\n");
  }
  fclose(fich);
  return 1;
 }

/// Display an image.
void ImageDisplay(const Image* img) {//percorre uma imagem e dá display
  uint32 d=0;
  for(int i=0; i<img->height; i++){
    for(int c=0; c<img->width; c++){
      printf("%d", img->image[d]);
      d++;
    }
    printf("\n");
  }
}

/// Get image width, i.e., the number of columns.
uint32 ImageGetWidth(const Image* img) { return img->width; }






/// Get image height, i.e., the number of rows.
uint32 ImageGetHeight(const Image* img) { return img->height;}






/// Count the number of ZERO and ONE pixels.
/// Update (*numZeros) and (*numOnes) with those counts.
void ImageStats(const Image* img, uint64* numZeros, uint64* numOnes) {
  int size= ImageGetHeight(img)*ImageGetWidth(img);
  uint64 zero=0;
  uint64 um=0;
  for(int i=0; i<size; i++){
    if(img->image[i]==0){
      zero++;
    }
    else
    {
      um++;
    }
  }
  numZeros=&zero;
  numOnes=&um;
}

/// Check if pixel position (x,y) is inside img.
/// On success, returns 1.
/// On failure, returns 0.
int ImageValidPos(const Image* img, uint32 x, uint32 y) {
    if(ImageGetHeight(img)>= y && ImageGetWidth(img)>= x){
      return 1;
    }
    else
    {
      return 0;
    }
 }

/// Get the pixel value at position (x,y).
/// Requires: x and y must be valid pixel coordinates.
/// On success, returns the pixel value.
/// On failure, returns 0.
uint8 ImageGetPixel(const Image* img, uint32 x, uint32 y) {
  if(!ImageValidPos(img, x, y)) return 0;
  
  int local= ImageGetWidth(img)*(y+1);
  int dif= ImageGetWidth(img)-(x+1);
  int final= local- dif-1;
  return img->image[final];
 }

/// Set the pixel at position (x,y) to new value.
/// Requires: x and y must be valid pixel coordinates.
/// Requires: value must be ZERO or ONE.
/// On success, returns 1.
/// On failure, returns 0.
int ImageSetPixel(Image* img, uint32 x, uint32 y, uint8 value) { 
  assert(value==0|| value==1);
  if(ImageValidPos(img, x, y)== 0) return 0;
  y++;
  int local= ImageGetWidth(img)*y;
  int dif= ImageGetWidth(img)-x;
  int final= local- dif - 1;

  img->image[final]= value;
  return 1;

 }

/// Set all image pixels to ONE.
/// Should never fail.
void ImageSetToONES(Image* img) {
  int size= ImageGetHeight(img)*ImageGetWidth(img);
  for(int i=0; i<size; i++){
    img->image[i]= 1;
  }
}

/// Set all image pixels to ZERO.
/// Should never fail.
void ImageSetToZEROS(Image* img) {
  int size= ImageGetHeight(img)*ImageGetWidth(img);
  for(int i=0; i<size; i++){
    img->image[i]= 0;
  }
}

/// Add a new column of ZEROS to the image.
/// Allocate a new array and shift columns, if necessary.
/// Requires: index must be valid, i.e., 0 <= index <= width.
/// On success, returns 1.
/// On failure, returns 0.
int ImageAddColumn(Image* img, uint32 index) { 
  assert(index<= ImageGetWidth(img));
  int d=0;
  int c=0;
  img->width = ImageGetWidth(img)+1;
  int size= ImageGetHeight(img)*ImageGetWidth(img);
  uint8 newarr[size];
  for(uint32 a=0; a<ImageGetHeight(img); a++){
    for(uint32 i=0; i<index; i++){
      newarr[c]= img->image[d];
      c++;
      d++;
    }
    newarr[c]=0;
    c++;
    for(uint32 b=index; b<(ImageGetWidth(img)-1); b++){
      newarr[c]=img->image[d];
      c++;
      d++;
    }
  }
  for(int q=0; q<size; q++){
    img->image[q]= newarr[q];
  }
    return 1;
  
 
}

/// Add a new row of ZEROS to the image.
/// Allocate a new array and shift rows, if necessary.
/// Requires: index must be valid, i.e., 0 <= index <= height.
/// On success, returns 1.
/// On failure, returns 0.
int ImageAddRow(Image* img, uint32 index) { 
  assert(index<= ImageGetHeight(img));
  int d=0;
  int c=0;
  img->height++;
  int size= ImageGetHeight(img)*ImageGetWidth(img);
  uint8 newarr[size];
  for(uint32 i=0; i<index; i++){
    for(uint32 a=0; a<ImageGetWidth(img); a++){
      newarr[d]= img->image[c];
      d++;
      c++;
    }
  }
  for(uint32 g=0; g<ImageGetWidth(img); g++){
      newarr[d]= 0;
      d++;
    }
  
  for(uint32 k=index; k<ImageGetHeight(img); k++){
    for(uint32 l=0; l<ImageGetWidth(img); l++){
      newarr[d]= img->image[c];
      d++;
      c++;
    }    
  }
  for(int q=0; q<size; q++){
    img->image[q]= newarr[q];
  }
  return 1;
 }

/// Create a new image by joining img2 at the right of img1.
/// Requires: both images must have the same number of rows.
/// On success, returns 1.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageHorizontalJoin(const Image* img1, const Image* img2, Image** pResult) {
  if(ImageGetHeight(img1)!=ImageGetHeight(img2)){
    pResult=NULL;
    return 0;
  }
  int wid = ImageGetWidth(img1)+ImageGetWidth(img2);
  Image* imgfin = ImageCreate(wid, ImageGetHeight(img1));
  int a=0;
  int f=0;
  int j=0;
  for(uint32 i=0; i<ImageGetHeight(img1) ;i++){
    for(uint32 b=0; b<ImageGetWidth(img1); b++){
      imgfin->image[a]= img1->image[f];
      a++;
      f++;
    }
    for(uint32 b=0; b<ImageGetWidth(img2); b++){
      imgfin->image[a]= img2->image[j];
      a++;
      j++;
    }
  }
  ImageDisplay(imgfin);
  pResult= &imgfin;
  return 1;
}

/// Create a new image by joining img2 at the bottom of img1.
/// Requires: both images must have the same number of columns.
/// On success, returns 1.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageVerticalJoin(const Image* img1, const Image* img2, Image** pResult) {
  if(ImageGetWidth(img1)!=ImageGetWidth(img2)){
    pResult=NULL;
    return 0;
  }
  int hei= ImageGetHeight(img1)+ImageGetHeight(img2);
  Image* imgfinal= ImageCreate(ImageGetWidth(img1), hei);
  int size1=(ImageGetHeight(img1)*ImageGetWidth(img1));
  int size2=(ImageGetHeight(img2)*ImageGetWidth(img2));
  int size=size1 + size2;
  int a=0;
  for(int i=0; i<size1;i++){
    imgfinal->image[i]= img1->image[i];
  }
  for(int d=size1; d< size; d++){
    imgfinal->image[d]= img2->image[a];
    a++;
  }
  pResult= &imgfinal;
  return 1;
}

/// Create two new images by splitting img.
/// The splitIndex row is the first row of the second image.
/// No empty images are created.
/// Requires: splitIndex must be a valid index.
/// I.e., 0 < splitIndex < (height - 1).
/// On success, returns 1.
/// Return 0 and set (*pResult1) and (*pResult2) to NULL, otherwise.
int ImageHorizontalSplit(const Image img, uint32 splitIndex, Image** pResult1,
                         Image** pResult2) {
  if(splitIndex > (&img)->width){
      pResult1=NULL;
      pResult2=NULL;
      return 0;
    }  
  int hei2=(&img)->height-splitIndex;
  int size1= (&img)->width*splitIndex;
  int size2= (&img)->width *(&img)->height;
  int a=0;
  Image* img1=ImageCreate((&img)->width, splitIndex);
  Image* img2=ImageCreate((&img)->width, hei2);

  for(int a=0; a<size1; a++){
    img1->image[a]= (&img)->image[a]; 
  }
  for(int b=size1; b<size2; b++){
    img2->image[a]= (&img)->image[b];
    a++;
  }
  ImageDisplay(img1);
  printf("\n");
  ImageDisplay(img2);
  return 1;
  
}

/// Create two new images by splitting img.
/// The splitIndex column is the first column of the second image.
/// No empty images are created.
/// Requires: splitIndex must be a valid index.
/// I.e, 0 < splitIndex < (width - 1).
/// On success, returns 1.
/// Return 0 and set (*pResult1) and (*pResult2) to NULL, otherwise.
int ImageVerticalSplit(const Image img, uint32 splitIndex, Image** pResult1,
                       Image** pResult2) {
    if(splitIndex > (&img)->height){
      pResult1=NULL;
      pResult2=NULL;
      return 0;
    }
    int c=0;
    int d=0;
    int e=0;
    int wid2=(&img)->width - splitIndex;
    Image* img1=ImageCreate(splitIndex, (&img)->height);
    Image* img2=ImageCreate(wid2, (&img)->height);
    for(uint32 a=0; a<(&img)->height ; a++){
      for(uint32 i=0; i<splitIndex; i++){
        img1->image[c]= (&img)->image[e];
        c++;
        e++;
      }
      for(uint32 b=splitIndex; b<(&img)->width; b++){
        img2->image[d]= (&img)->image[e];
        d++;
        e++;
      }
    }
    ImageDisplay(img1);
    printf("\n");
    ImageDisplay(img2);
    return 1;
}


/// Rotate the image 90 degrees clockwise.
/// Reallocate memory if the image is not a square image.
/// On success, returns 1.
/// On failure, returns 0.
int ImageRotate90DegCW(Image* img) { 
  if(img==NULL)return 0;
  int a= img->height;
  int b= img->width;
  int c=0;
  int size= a*b;
  int size1= size;
  uint8 arr[size];
  //percorre as colunas de baixo para cima começando na primeira coluna
  for(int f=(ImageGetWidth(img)); f>=0; f--){//percorre uma linha
    size= size-f;                           //reduz reduz o size para o começo da última linha conforme o f diminui aumenta até alcançar o final da ultima linha
    for(int i=0; i<a; i++){//percorre um elemento de cada linha da mesma coluna
      arr[c]=img->image[size];
      size= size-ImageGetWidth(img); //atualiza o size para a linha anterior mas na mesma posição de x
      c++; 
    }
   size= a*b;
  }
  if(ImageGetHeight(img)!=ImageGetWidth(img)){
    img->height= img->width;
    img->width= a; 
  }
  for(int g=0; g<size1; g++){
    img->image[g]= arr[g];
  }
  return 1;
}

/// Rotate the image 90 degrees counter-clockwise.
/// Reallocate memory if the image is not a square image.
/// On success, returns 1.
/// On failure, returns 0.
int ImageRotate90DegCCW(Image* img) { 
  int a= img->height;
  int b= img->width;
  int c=0;
  int d=0; 
  int size= a*b;
  uint8 arr[size];
  //transforma linhas em colunas comecando da primeira da ultima coluna
  for(int f=(ImageGetWidth(img)-1); f>=0; f--){
    d= f;
    for(int i=0; i<a; i++){ //percorre as colunas
      arr[c]=img->image[d];
      d= d+ImageGetWidth(img); //acrescenta o valor de uma linha para obter a próxima
      c++; 
    }
  }
  if(ImageGetHeight(img)!=ImageGetWidth(img)){
    img->height= img->width;
    img->width= a; 
  }
  for(int g=0; g<size; g++){
    img->image[g]= arr[g];
  }
  return 1;
}

/// Check if two images are the same.
/// I.e., they have the same size and the same pixel values.
int ImageEqualTo(const Image* img1, const Image img2) { 
  int size1= img1->height * img1->width;
  //se a largura ou o comprim forem diferentes devolve 0
  if((ImageGetHeight(img1)!=(&img2)->height)|| ImageGetWidth(img1)!= ImageGetWidth(&img2)){return 0;}
  //se algum dos valores for 0 devolve 0
  for(int i=0; i<size1; i++){
    if(img1->image[i] != (&img2)->image[i]) return 0;
  }
  return 1;
}

/// Check if two images are different.
int ImageDifferentFrom(const Image* img1, const Image img2) {
  return !ImageEqualTo(img1, img2);
 }

/// Negate each one of the image pixels.
/// Should never fail.
void ImageNEGATE(Image* img) {
  int size= ImageGetHeight(img)*ImageGetWidth(img);
  //percorre o array e nega cada valor
  for(int i=0; i<size;i++){
    img->image[i]= !img->image[i];
  }
}

/// Pixel by pixel AND.
/// Create a new result image.
/// Return 1, if images are of the same size.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageAND(const Image* img1, const Image* img2, Image** pResult) {
  int size1= ImageGetHeight(img1)* ImageGetWidth(img2);
  //se a largura ou o comprim forem diferentes devolve 0
  if((ImageGetHeight(img1)!=ImageGetHeight(img2))|| ImageGetWidth(img1)!= ImageGetWidth(img2)){
    pResult=NULL;
    return 0;
  }
  //operação and nas duas
  Image* imgfin = ImageCreate(ImageGetWidth(img1), ImageGetHeight(img1));
  for(int i=0; i<size1; i++){
    imgfin->image[i]= img1->image[i] & img2->image[i];
  }

  pResult= &imgfin;
  return 1;
}

/// Pixel by pixel OR
/// Pixel by pixel AND.
/// Return 1, if images are of the same size.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageOR(const Image* img1, const Image* img2, Image** pResult) {
  int size1= ImageGetHeight(img1)* ImageGetWidth(img2);
  //se a largura ou o comprim forem diferentes devolve 0
  if((ImageGetHeight(img1)!=ImageGetHeight(img2))|| ImageGetWidth(img1)!= ImageGetWidth(img2)){  
    pResult=NULL;
    return 0;
  }
  Image* imgfin =ImageCreate(ImageGetWidth(img1), ImageGetHeight(img1));
  //operaçao or nas duas
  for(int i=0; i<size1; i++){
    imgfin->image[i] = img1->image[i] | img2->image[i];
  }
  pResult= &imgfin;
  return 1;

}

/// Pixel by pixel XOR
/// Pixel by pixel AND.
/// Return 1, if images are of the same size.
/// Return 0 and set (*pResult) to NULL, otherwise.
int ImageXOR(const Image* img1, const Image* img2, Image** pResult) {
  uint32 size1= ImageGetHeight(img1)* ImageGetWidth(img2);//tamanho imagem 1 
  //se a largura ou o comprim forem diferentes devolve 0
  if((ImageGetHeight(img1)!=ImageGetHeight(img2))|| ImageGetWidth(img1)!= ImageGetWidth(img2)){
    pResult=NULL;
    return 0;
  }
  Image* imgfin =ImageCreate(ImageGetWidth(img1), ImageGetHeight(img1));
  //percorre o tamanho da imagem e operação xor nas duas
  for(uint32 i=0; i<size1; i++){
    imgfin->image[i] = img1->image[i] ^ img2->image[i];
  }
  pResult= &imgfin;
  return 1;

}

/// Check if rectangular area (x,y,w,h) is completely inside img.
int ImageValidRect(const Image* img, uint32 x, uint32 y, uint32 width,
                   uint32 height) {
  uint32 c= x+width;   //alcance total da largura da imagem 2 na imagem 1
  uint32 l= y+height; //o mesmo da largura
  if(c>ImageGetWidth(img))return 0; //alcance total superior á largura da imagem 1 
  if(l>ImageGetHeight(img)) return 0;// o mesmo da largura
  return 1;
}

/// Crop a rectangular subimage from img.
/// The rectangle is specified by the top left corner coords (x, y) and
/// width w and height h.
/// Requires:
///   The rectangle must be inside the original image.
/// Ensures:
///   The original img is not modified.
///   The returned image has width w and height h.
/// On success, a new image is returned.
/// On failure, returns NULL.
Image* ImageCrop(const Image* img, uint32 x, uint32 y, uint32 width,
                 uint32 height) {
  if(!ImageValidRect(img, x, y, width, height)) return NULL;
  int c=0;
  int d=0;
  Image* final= ImageCreate(width, height);
  for(uint32 i=y ; i<(y+height); i++){//percorre do y até ao fim da altura do novo quadrado
    d= i*img->width;                   //inicializa o d na linha do y e atualiza-o cada vez que uma nova linha aparece
    d=d+x;                            //atualiza-o para estar em conformidade com a coluna x
    for(uint32 a=x; a<(x+width); a++){//percorre do x até ao fim da largura do novo quadrado
      final->image[c]=img->image[d];
      c++;
      d++; 
    }
  }
  return final;
}

/// Paste an image into a larger image.
/// Paste img2 into position (x, y) of img1.
/// This modifies img1 in-place: no allocation involved.
/// Requires: img2 must fit inside img1 at position (x, y).
/// On success, returns 1.
/// On failure, returns 0.
int ImagePaste(Image* img1, uint32 x, uint32 y, const Image* img2) {
  if(!ImageValidRect(img1, x, y, ImageGetWidth(img2), ImageGetHeight(img2)))return 0;
  int c=0;
  int d=0;
  for(uint32 i=y ; i<(img2->height+y); i++){//percorre do y até ao fim da altura do novo quadrado
    d=i*img1->width;                          //inicializa o d na linha do y e atualiza-o cada vez que uma nova linha aparece
    d=d+x;                                     //atualiza-o para estar em conformidade com a coluna x
    for(uint32 a=x; a<(img2->width+x); a++){
  
      img1->image[d]=img2->image[c];
      c++;
      d++; 
    }
  }
  return 1;
}

/// Locate a subimage inside another image.
/// Searches for img2 inside img1.
/// If a match is found, returns 1 and matching position is set in (*px,*py).
/// If no match is found, returns 0 and (*px, *py) are left untouched.
int ImageLocateSubImage(const Image* img1, const Image* img2, uint32* px,
                        uint32* py) {
  if(!ImageValidRect(img1, 0,0, img2->width, img2->height))return 0;
  Image* cropped;
  for(uint32 i=0; (img1->height) >= (i+img2->height) ; i++){//percorre a altura até ser impossível encontrar 
    for(uint32 a=0; (img1->width) >= ( a + img2->width); a++){//percorre a linha até ser impossível encontrar
      cropped= ImageCrop(img1, a, i, img2->width, img2->height);
      if(ImageEqualTo(cropped, *img2)){
        px=&a;
        py=&i;
        return 1;
      }
    }
  }
  return 0;
}

